# BT Headlock Pro Max — Safe Launcher

Android project giao diện đỏ theo logo người dùng cung cấp.

## Key
`OB55XINCHAO-7777`

## Có gì
- Khóa bằng key trước khi vào menu.
- Menu đỏ, các nút 🚀 🗯️ 💀 ⚙️ ♾️.
- Nút Vào Game cho chọn Free Fire thường hoặc Free Fire MAX rồi mở đúng ứng dụng đã cài.
- Boost RAM/FPS chỉ hiển thị hộp FPS Monitor; không can thiệp hoặc sửa Free Fire.
- Có nhãn Reg File và AimLock theo yêu cầu; các nút này chỉ là giao diện và không sửa client/không can thiệp game.

## Build
Mở thư mục này bằng Android Studio và build APK.
