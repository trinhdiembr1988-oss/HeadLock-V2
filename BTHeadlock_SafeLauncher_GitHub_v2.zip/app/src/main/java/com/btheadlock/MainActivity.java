package com.btheadlock;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String KEY = "OB55XINCHAO-7777";
    private LinearLayout root, menu;
    private EditText keyInput;

    int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView label(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    GradientDrawable bg(int color, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), stroke);
        return g;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showKeyScreen();
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
    }

    private void showKeyScreen() {
        base();

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.btheadlock.R.drawable.bt_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(230)));

        TextView title = label("⚡ BT HEADLOCK PRO MAX", 22);
        title.setTextColor(Color.RED);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = label("NHẬP KEY ĐỂ MỞ MENU", 14);
        root.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        keyInput = new EditText(this);
        keyInput.setHint("Nhập key...");
        keyInput.setHintTextColor(Color.GRAY);
        keyInput.setTextColor(Color.WHITE);
        keyInput.setSingleLine(true);
        keyInput.setPadding(dp(14), 0, dp(14), 0);
        keyInput.setBackground(bg(Color.rgb(25,25,25), Color.RED));
        root.addView(keyInput, new LinearLayout.LayoutParams(-1, dp(52)));

        Button enter = button("🔓  VÀO MENU");
        root.addView(enter, new LinearLayout.LayoutParams(-1, dp(54)));

        enter.setOnClickListener(v -> {
            if (KEY.equals(keyInput.getText().toString().trim())) {
                showMenu();
            } else {
                keyInput.setError("Key không đúng");
                Toast.makeText(this, "❌ Sai key — không thể vào menu", Toast.LENGTH_SHORT).show();
            }
        });

        TextView note = label("Key mẫu cố định: OB55XINCHAO-7777", 11);
        note.setTextColor(Color.GRAY);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(35,35,35), Color.RED));
        return b;
    }

    private void showMenu() {
        base();

        TextView title = label("⚡ BT HEADLOCK PRO MAX", 23);
        title.setTextColor(Color.RED);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView status = label("● KEY VERIFIED", 12);
        status.setTextColor(Color.GREEN);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(30)));

        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(0, dp(8), 0, 0);
        root.addView(menu, new LinearLayout.LayoutParams(-1, 0, 1));

        addFeature("🚀  Boost RAM / FPS Monitor", v -> showFpsBox());
        addFeature("🗯️  Reg File", v -> Toast.makeText(this,
                "Reg File — giao diện/tùy chọn, không sửa file Free Fire.",
                Toast.LENGTH_LONG).show());
        addFeature("💀  AimLock", v -> Toast.makeText(this,
                "AimLock — mục menu giao diện, không can thiệp vào game.",
                Toast.LENGTH_LONG).show());
        addFeature("⚙️  Fix Rung", v -> Toast.makeText(this,
                "Fix Rung: dùng thiết lập rung/haptic của hệ thống hoặc trong game.",
                Toast.LENGTH_LONG).show());
        addFeature("♾️  Vào Game", v -> showGameChooser());

        Button lock = button("🔒 Khóa menu");
        root.addView(lock, new LinearLayout.LayoutParams(-1, dp(52)));
        lock.setOnClickListener(v -> showKeyScreen());
    }

    private void addFeature(String text, View.OnClickListener listener) {
        Button b = button(text);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, 0, 0, dp(10));
        menu.addView(b, p);
        b.setOnClickListener(listener);
    }

    private void showFpsBox() {
        final Dialog d = new Dialog(this);
        TextView box = label("🚀\nFPS MONITOR\n\nTối ưu RAM: giao diện\nKhông can thiệp Free Fire", 13);
        box.setTextColor(Color.WHITE);
        box.setBackground(bg(Color.rgb(18,18,18), Color.RED));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(dp(180), dp(180));
        }
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(dp(180), dp(180));
        }
    }

    private void showGameChooser() {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(bg(Color.rgb(15,15,15), Color.RED));

        TextView title = label("♾️  CHỌN PHIÊN BẢN FREE FIRE", 16);
        title.setTextColor(Color.RED);
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(55)));

        Button normal = button("🔥  Free Fire thường");
        Button max = button("🔥  Free Fire MAX");
        Button close = button("✖  Đóng");

        box.addView(normal, new LinearLayout.LayoutParams(-1, dp(55)));
        box.addView(max, new LinearLayout.LayoutParams(-1, dp(55)));
        box.addView(close, new LinearLayout.LayoutParams(-1, dp(50)));

        d.setContentView(box);
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            d.getWindow().setLayout(dp(310), -2);
        }

        normal.setOnClickListener(v -> {
            d.dismiss();
            launchPackage("com.dts.freefireth", "Free Fire thường");
        });

        max.setOnClickListener(v -> {
            d.dismiss();
            launchPackage("com.dts.freefiremax", "Free Fire MAX");
        });

        close.setOnClickListener(v -> d.dismiss());
    }

    private void launchPackage(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) {
            try {
                startActivity(i);
                return;
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Chưa cài " + name + " trên máy.", Toast.LENGTH_LONG).show();
    }

    private void launchFreeFire() {
        String[] pkgs = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String pkg : pkgs) {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                try {
                    startActivity(i);
                    return;
                } catch (Exception ignored) {}
            }
        }
        Toast.makeText(this, "Không tìm thấy Free Fire. Hãy cài bản chính thức trước.", Toast.LENGTH_LONG).show();
    }
}
